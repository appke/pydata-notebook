#《十分钟搞定pandas》

This is the official document [*10 minutes in pandas*](http://pandas.pydata.org/pandas-docs/stable/10min.html) in Chinese.

**在线阅读**：[十分钟搞定pandas](http://nbviewer.ipython.org/github/Wenice/10-Minutes-to-pandas/blob/master/10%20Minutes%20to%20pandas.ipynb)